/**
 * github-deploy.js — Auto-deploy a GitHub usando la API REST (sin Git instalado)
 * Requiere: GITHUB_TOKEN en archivo .env
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

const ROOT = path.join(__dirname);
const CONFIG_FILE = path.join(ROOT, '.github-config.json');

// Configuración del repositorio
const REPO_OWNER = 'JairoNP300';
const REPO_NAME = 'Sistema-asistencia';
const BRANCH = 'main';

console.log(`📁 Repositorio: ${REPO_OWNER}/${REPO_NAME} (${BRANCH})`);

const IGNORE = ['node_modules', '.git', '.github-config.json', 'tunnel.log', 'tunnel.err', 'data.json', 'build.hash', 'github-deploy.js'];

function shouldIgnore(filename) {
    return IGNORE.some(ig => filename.includes(ig));
}

// Obtener token de .env
function getToken() {
    const envPath = path.join(ROOT, '.env');
    if (!fs.existsSync(envPath)) return null;
    const env = fs.readFileSync(envPath, 'utf8');
    const match = env.match(/GITHUB_TOKEN=(.+)/);
    return match ? match[1].trim() : null;
}

// Hacer petición a la API de GitHub
function githubRequest(path, method = 'GET', data = null, token) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'api.github.com',
            port: 443,
            path: path,
            method: method,
            headers: {
                'User-Agent': 'QR-Asistencia-Deploy',
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/vnd.github+json',
                'X-GitHub-Api-Version': '2022-11-28',
                'Content-Type': 'application/json'
            }
        };

        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(body);
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        resolve(json);
                    } else {
                        reject(new Error(`GitHub API Error ${res.statusCode}: ${json.message || body}`));
                    }
                } catch (e) {
                    reject(new Error(`Parse error: ${body}`));
                }
            });
        });

        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

// Obtener SHA del último commit
async function getLatestCommitSha(token) {
    const ref = await githubRequest(`/repos/${REPO_OWNER}/${REPO_NAME}/git/ref/heads/${BRANCH}`, 'GET', null, token);
    return ref.object.sha;
}

// Crear blob
async function createBlob(content, token) {
    const data = {
        content: Buffer.from(content).toString('base64'),
        encoding: 'base64'
    };
    return await githubRequest(`/repos/${REPO_OWNER}/${REPO_NAME}/git/blobs`, 'POST', data, token);
}

// Crear árbol
async function createTree(baseSha, files, token) {
    const tree = files.map(f => ({
        path: f.path,
        mode: '100644',
        type: 'blob',
        sha: f.sha
    }));

    const data = {
        base_tree: baseSha,
        tree: tree
    };
    return await githubRequest(`/repos/${REPO_OWNER}/${REPO_NAME}/git/trees`, 'POST', data, token);
}

// Crear commit
async function createCommit(message, treeSha, parentSha, token) {
    const data = {
        message: message,
        tree: treeSha,
        parents: [parentSha]
    };
    return await githubRequest(`/repos/${REPO_OWNER}/${REPO_NAME}/git/commits`, 'POST', data, token);
}

// Actualizar referencia
async function updateRef(commitSha, token) {
    const data = {
        sha: commitSha,
        force: false
    };
    return await githubRequest(`/repos/${REPO_OWNER}/${REPO_NAME}/git/refs/heads/${BRANCH}`, 'PATCH', data, token);
}

// Obtener lista de archivos modificados
function getChangedFiles() {
    const files = [];
    const stack = [{ dir: ROOT, base: '' }];

    while (stack.length > 0) {
        const { dir, base } = stack.pop();
        const items = fs.readdirSync(dir);

        for (const item of items) {
            const fullPath = path.join(dir, item);
            const relPath = path.join(base, item).replace(/\\/g, '/');

            if (shouldIgnore(item)) continue;

            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                stack.push({ dir: fullPath, base: relPath });
            } else {
                const content = fs.readFileSync(fullPath);
                const hash = crypto.createHash('sha256').update(content).digest('hex');
                files.push({ path: relPath, fullPath, hash, content: content.toString('base64') });
            }
        }
    }

    return files;
}

// Deploy principal
async function deploy() {
    const token = getToken();
    if (!token) {
        console.error('❌ Error: No se encontró GITHUB_TOKEN en archivo .env');
        console.log('💡 Agrega tu token de GitHub al archivo .env:');
        console.log('   GITHUB_TOKEN=ghp_tu_token_aqui');
        console.log('   Obtén uno en: https://github.com/settings/tokens');
        return;
    }

    try {
        console.log('🔍 Verificando cambios...');
        const files = getChangedFiles();

        // Leer estado anterior
        let lastState = {};
        if (fs.existsSync(CONFIG_FILE)) {
            try {
                lastState = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
            } catch (e) {}
        }

        // Filtrar solo archivos modificados
        const changedFiles = files.filter(f => lastState[f.path] !== f.hash);

        if (changedFiles.length === 0) {
            console.log('✅ Sin cambios nuevos para subir.');
            return;
        }

        console.log(`📤 Subiendo ${changedFiles.length} archivos modificados...`);

        // Obtener SHA del último commit
        const latestCommitSha = await getLatestCommitSha(token);
        console.log(`📝 Commit base: ${latestCommitSha.substring(0, 7)}`);

        // Crear blobs para archivos modificados
        const fileBlobs = [];
        for (const file of changedFiles) {
            process.stdout.write(`  → ${file.path}... `);
            const blob = await createBlob(Buffer.from(file.content, 'base64'), token);
            fileBlobs.push({ path: file.path, sha: blob.sha });
            console.log('✓');
        }

        // Crear nuevo árbol
        const tree = await createTree(latestCommitSha, fileBlobs, token);
        console.log(`🌳 Árbol creado: ${tree.sha.substring(0, 7)}`);

        // Crear commit
        const timestamp = new Date().toLocaleString('es-MX');
        const commit = await createCommit(`Auto: ${timestamp}`, tree.sha, latestCommitSha, token);
        console.log(`💾 Commit creado: ${commit.sha.substring(0, 7)}`);

        // Actualizar referencia
        await updateRef(commit.sha, token);
        console.log(`🚀 ¡Deploy exitoso! Commit: ${commit.sha.substring(0, 7)}`);

        // Guardar estado
        const newState = {};
        files.forEach(f => newState[f.path] = f.hash);
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(newState, null, 2));

        // Escribir hash del build
        const buildHash = Date.now().toString(36);
        fs.writeFileSync(path.join(ROOT, 'build.hash'), buildHash);
        console.log(`🔔 Render se actualizará automáticamente en ~2 minutos`);

    } catch (error) {
        console.error('❌ Error en deploy:', error.message);
        if (error.message.includes('Bad credentials')) {
            console.log('💡 Verifica que tu GITHUB_TOKEN sea válido y tenga permisos de repo');
        }
    }
}

// Watch mode
function watch() {
    console.log('👀 Auto-deploy activo. Cambios → GitHub → Render automáticamente.\n');

    let timer = null;
    const DEBOUNCE_MS = 1500;

    function scheduleDeployment() {
        if (timer) clearTimeout(timer);
        timer = setTimeout(deploy, DEBOUNCE_MS);
    }

    fs.watch(ROOT, { recursive: true }, (event, filename) => {
        if (filename && !shouldIgnore(filename)) {
            process.stdout.write(`\r📝 ${filename} → subiendo en ${DEBOUNCE_MS/1000}s...`);
            scheduleDeployment();
        }
    });
}

// Ejecutar
if (require.main === module) {
    const args = process.argv.slice(2);
    if (args.includes('--watch') || args.includes('-w')) {
        watch();
    } else {
        deploy().then(() => {
            if (args.includes('--watch') || args.includes('-w')) {
                watch();
            }
        });
    }
}

module.exports = { deploy, watch };
