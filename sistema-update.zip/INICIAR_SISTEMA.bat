@echo off
chcp 65001 >nul
title QR-Asistencia - Iniciando Sistema
color 0A
cd /d "%~dp0"

echo.
echo =====================================================
echo  QR-ASISTENCIA - Sistema de Control de Personal
echo  Iniciando optimizacion del sistema...
echo =====================================================
echo.

REM === VERIFICAR NODE.JS ===
node --version >nul 2>&1
if errorlevel 1 (
    color 0C
    echo  ERROR: Node.js no esta instalado.
    echo  Descargalo en: https://nodejs.org
    echo.
    pause
    exit /b 1
)

REM === LIMPIEZA Y OPTIMIZACION DEL SISTEMA ===
echo [1/5] Limpiando cache de npm...
if exist "node_modules\.cache" rmdir /s /q "node_modules\.cache" 2>nul
echo  - Cache limpiado

echo [2/5] Verificando integridad de datos...
node optimize-data.js
echo  - Datos verificados

echo [3/5] Instalando dependencias...
if not exist "node_modules\express" (
    call npm install
    if errorlevel 1 (
        color 0C
        echo  ERROR: Fallo npm install.
        pause
        exit /b 1
    )
    echo  - Dependencias instaladas
) else (
    echo  - Dependencias ya instaladas
)

echo [4/5] Verificando configuracion GitHub...
node -e "if(!require('fs').existsSync('.env'))process.exit(1)"
if errorlevel 1 (
    echo  - Advertencia: No se encontro archivo .env
) else (
    echo  - Configuracion OK
)

echo [5/5] Subiendo cambios a GitHub...
node github-deploy.js
if errorlevel 1 (
    echo  - Advertencia: Revisa que tengas GITHUB_TOKEN configurado
    echo  - Obtén uno en: https://github.com/settings/tokens
) else (
    echo  - Cambios subidos correctamente
)

echo.
echo =====================================================
echo  SISTEMA OPTIMIZADO Y LISTO
echo =====================================================
echo  URL: https://sistema-asistencia-s0m2.onrender.com
echo  Admin: Solo contrasena requerida
echo  QR: Acceso directo sin contrasena
echo.
echo  Caracteristicas:
echo  - Deteccion automatica de entradas tardias
echo  - Limpieza automatica de cache
echo  - Auto-deploy cada 30 segundos
echo  - Datos optimizados al iniciar
echo =====================================================
echo.
echo Abriendo navegador...
start https://sistema-asistencia-s0m2.onrender.com

echo Iniciando servidor local...
echo Presiona Ctrl+C para detener
echo.

REM Iniciar servidor Y auto-deploy en paralelo
node -e "const {spawn}=require('child_process');const s=spawn('node',['server.js'],{stdio:'inherit'});const d=spawn('node',['github-deploy.js','--watch'],{stdio:'inherit'});s.on('close',()=>process.exit());process.on('SIGINT',()=>{s.kill();d.kill();process.exit();});"
