/**
 * simple-deploy.js — Deploy simplificado usando Content API de GitHub
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const TOKEN = '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';
const REPO = 'JairoNP300/Sistema-asistencia';
const BRANCH = 'main';

const IGNORE = ['node_modules', '.git', 'simple-deploy.js', 'github-deploy.js', '.github-config.json'];

function shouldIgnore(filename) {
    return IGNORE.some(ig => filename.includes(ig));
}

function apiRequest(method, path, data = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'api.github.com',
            path: `/repos/${REPO}${path}`,
            method: method,
            headers: {
                'Authorization': `token ${TOKEN}`,
                'User-Agent': 'QR-Asistencia',
                'Accept': 'application/vnd.github.v3+json',
                'Content-Type': 'application/json'
            }
        };

        if (data) {
            const postData = JSON.stringify(data);
            options.headers['Content-Length'] = Buffer.byteLength(postData);
        }

        const req = https.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    resolve(JSON.parse(body));
                } else {
                    reject(new Error(`HTTP ${res.statusCode}: ${body}`));
                }
            });
        });

        req.on('error', reject);
        if (data) req.write(JSON.stringify(data));
        req.end();
    });
}

async function getFileContent(filepath) {
    try {
        return fs.readFileSync(filepath, 'utf8');
    } catch (e) {
        return fs.readFileSync(filepath);
    }
}

async function updateFile(filePath, content, message) {
    try {
        // Intentar obtener el SHA del archivo existente
        const fileInfo = await apiRequest('GET', `/contents/${filePath}?ref=${BRANCH}`);
        const sha = fileInfo.sha;
        
        // Actualizar archivo
        await apiRequest('PUT', `/contents/${filePath}`, {
            message: message,
            content: Buffer.from(content).toString('base64'),
            sha: sha,
            branch: BRANCH
        });
        console.log(`  ✅ ${filePath} (actualizado)`);
    } catch (e) {
        if (e.message.includes('404')) {
            // Crear nuevo archivo
            await apiRequest('PUT', `/contents/${filePath}`, {
                message: message,
                content: Buffer.from(content).toString('base64'),
                branch: BRANCH
            });
            console.log(`  ✅ ${filePath} (nuevo)`);
        } else {
            throw e;
        }
    }
}

async function deploy() {
    console.log('🚀 Iniciando deploy a GitHub...\n');
    
    // Lista de archivos importantes a subir
    const files = [
        'qr-display.html',
        'index.html',
        'app.js',
        'server.js',
        'styles.css',
        'checkin.html',
        'checkin.js',
        'checkin.css',
        'crypto-utils.js',
        'package.json',
        'Procfile',
        'README.md',
        '.env',
        'manifest.json',
        'optimize-data.js',
        'watch-deploy.js',
        'INICIAR_SISTEMA.bat',
        'build.hash'
    ];
    
    const message = `Auto: ${new Date().toLocaleString('es-MX')} - Sistema restaurado con qr-display`;
    
    for (const file of files) {
        const fullPath = path.join(__dirname, file);
        if (!fs.existsSync(fullPath)) {
            console.log(`  ⚠️ ${file} no encontrado, omitiendo`);
            continue;
        }
        
        try {
            const content = await getFileContent(fullPath);
            await updateFile(file, content, message);
        } catch (e) {
            console.error(`  ❌ ${file}: ${e.message.substring(0, 100)}`);
        }
    }
    
    // Subir archivos de models
    const modelsDir = path.join(__dirname, 'models');
    if (fs.existsSync(modelsDir)) {
        const modelFiles = fs.readdirSync(modelsDir);
        for (const modelFile of modelFiles) {
            const filePath = `models/${modelFile}`;
            const fullPath = path.join(modelsDir, modelFile);
            try {
                const content = fs.readFileSync(fullPath, 'utf8');
                await updateFile(filePath, content, message);
            } catch (e) {
                console.error(`  ❌ ${filePath}: ${e.message.substring(0, 100)}`);
            }
        }
    }
    
    // Subir archivos de utils
    const utilsDir = path.join(__dirname, 'utils');
    if (fs.existsSync(utilsDir)) {
        const utilFiles = fs.readdirSync(utilsDir);
        for (const utilFile of utilFiles) {
            const filePath = `utils/${utilFile}`;
            const fullPath = path.join(utilsDir, utilFile);
            try {
                const content = fs.readFileSync(fullPath, 'utf8');
                await updateFile(filePath, content, message);
            } catch (e) {
                console.error(`  ❌ ${filePath}: ${e.message.substring(0, 100)}`);
            }
        }
    }
    
    console.log('\n✅ Deploy completado!');
    console.log('⏱️ Render se actualizará en ~2 minutos');
}

deploy().catch(e => {
    console.error('❌ Error:', e.message);
    if (e.message.includes('401')) {
        console.log('\n💡 El token no es válido o ha expirado.');
        console.log('   Crea uno nuevo en: https://github.com/settings/tokens');
    }
    if (e.message.includes('404')) {
        console.log('\n💡 No se encontró el repositorio o archivo.');
        console.log('   Verifica que el token tenga permiso "repo"');
    }
});
